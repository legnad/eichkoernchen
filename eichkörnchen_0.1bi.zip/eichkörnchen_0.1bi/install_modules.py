import subprocess
import sys

def install(package):
    subprocess.call([sys.executable, "-m", "pip", "install", package])

if __name__ == '__main__':
    install('matplotlib')
    install('numpy')
    install('PyQt5')
    install('opencv-python')
    install('pandas')
    install('scipy')
